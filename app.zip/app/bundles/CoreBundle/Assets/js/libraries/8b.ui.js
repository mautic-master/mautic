/*! ========================================================================
 * Mautic UI v1.0.0
 * Copyright 2014 Mautic
 * ======================================================================== */

if (typeof jQuery === "undefined") { throw new Error("This application requires jQuery"); }

;(function($, window, document, undefined) {
  
})(jQuery, window, document);