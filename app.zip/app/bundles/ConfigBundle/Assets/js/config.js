//ConfigBundle
/**
 * @deprecated - use Mautic.initializeFormFieldVisibilitySwitcher() instead
 * @param formName
 */
Mautic.hideSpecificConfigFields = function(formName) {
	initializeFormFieldVisibilitySwitcher(formName);
}